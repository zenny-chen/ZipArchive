#import "SSZipArchive/SSZipArchive.h"

int main(void)
{
    NSAutoreleasePool *pool = NSAutoreleasePool.new;

    NSString *zipPath = @"/root/my-programs/ObjC-Programs/zip-archive/test-files/cargo.zip";
    NSString *srcDir = @"/root/my-programs/rust-programs/";
    NSString *unzipDir = @"/root/my-programs/ObjC-Programs/zip-archive/test-files/cargo";

    [SSZipArchive createZipFileAtPath:zipPath withContentsOfDirectory:srcDir];
        
    [SSZipArchive unzipFileAtPath:zipPath toDestination:unzipDir];

    [pool drain];
}


